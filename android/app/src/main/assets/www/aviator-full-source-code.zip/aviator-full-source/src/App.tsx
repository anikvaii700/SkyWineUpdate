/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RoundStatus, BetState, RoundHistoryItem, LivePlayerBet, ActiveGameTab } from './types/game';
import { Header } from './components/Header';
import { HistoryRibbon } from './components/HistoryRibbon';
import { FlightCanvas } from './components/FlightCanvas';
import { BetPanel } from './components/BetPanel';
import { LiveBetsTable } from './components/LiveBetsTable';
import { WinNotification } from './components/WinNotification';
import { AIPredictorModal } from './components/AIPredictorModal';
import { DepositModal } from './components/DepositModal';
import { RulesModal } from './components/RulesModal';
import { WingoGame } from './components/WingoGame';
import { AuthModal } from './components/AuthModal';
import { AdminPanel } from './components/AdminPanel';
import { getStoredDepositRequests, getStoredWithdrawalRequests } from './services/manualPayment';
import { soundManager } from './services/audio';
import { Language, translations } from './utils/i18n';
import {
  auth,
  getOrCreateUserProfile,
  syncUserBalanceToFirestore,
  recordWalletTransaction,
  recordBetHistory,
  UserWalletProfile,
} from './services/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  AppUser,
  getActivePhoneSession,
  syncPhoneAccountBalance,
} from './services/phoneAuth';
import { recordUserBet } from './services/userManagement';
import { usePWAInstall } from './hooks/usePWAInstall';
import { PWAInstallModal } from './components/PWAInstallModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SplashScreen } from './components/SplashScreen';
import { MobileSideDrawer } from './components/MobileSideDrawer';
import { ExitModal } from './components/ExitModal';
import { MarqueeTicker } from './components/MarqueeTicker';
import { AndroidStudioExportModal } from './components/AndroidStudioExportModal';
import { Plane } from 'lucide-react';

const INITIAL_BALANCE = 0; // Starts at 0 for real authenticated accounts

export default function App() {
  const [balance, setBalance] = useState<number>(INITIAL_BALANCE);
  const [roundStatus, setRoundStatus] = useState<RoundStatus>('WAITING');
  const [currentMultiplier, setCurrentMultiplier] = useState<number>(1.0);
  const [finalCrashMultiplier, setFinalCrashMultiplier] = useState<number>(1.84);
  const [waitingCountdown, setWaitingCountdown] = useState<number>(5.0);

  // Mobile App Native Experience & Splash Screen State
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState<boolean>(false);
  const [isExitModalOpen, setIsExitModalOpen] = useState<boolean>(false);
  const [hasExitedApp, setHasExitedApp] = useState<boolean>(false);
  const lastBackPressTimeRef = useRef<number>(0);

  const handleFinishSplash = useCallback(() => {
    setShowSplash(false);
  }, []);

  // Mobile App PWA & Android Studio State
  const [isInstallModalOpen, setIsInstallModalOpen] = useState<boolean>(false);
  const [isAndroidStudioOpen, setIsAndroidStudioOpen] = useState<boolean>(false);
  const { isInstalled: isAppInstalled, isMobile } = usePWAInstall();

  // Language & UI Modals
  const [lang, setLang] = useState<Language>('bn');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isDepositOpen, setIsDepositOpen] = useState<boolean>(false);
  const [walletTab, setWalletTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [pendingDepositCount, setPendingDepositCount] = useState<number>(0);
  const [isPredictorOpen, setIsPredictorOpen] = useState<boolean>(true); // open by default as in screenshot
  const [activeGameTab, setActiveGameTab] = useState<ActiveGameTab>('AVIATOR');

  // User Auth & Cloud / Local Server Wallet State
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserWalletProfile | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);

  // Win Banner Notification
  const [winNotification, setWinNotification] = useState<{ amount: number; multiplier: number } | null>(null);

  // Dual Betting Panels
  const [bet1, setBet1] = useState<BetState>({
    id: 'bet-1',
    amount: 1000,
    isPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: null,
    winAmount: null,
    isAutoCashOut: false,
    autoCashOutMultiplier: 2.0,
    isAutoBet: false,
  });

  const [bet2, setBet2] = useState<BetState>({
    id: 'bet-2',
    amount: 1000,
    isPlaced: false,
    cashedOut: false,
    cashedOutMultiplier: null,
    winAmount: null,
    isAutoCashOut: false,
    autoCashOutMultiplier: 2.0,
    isAutoBet: false,
  });

  // Recent multiplier history
  const [history, setHistory] = useState<RoundHistoryItem[]>([
    { id: '1', crashMultiplier: 2.14, timestamp: Date.now() - 60000 },
    { id: '2', crashMultiplier: 3.12, timestamp: Date.now() - 120000 },
    { id: '3', crashMultiplier: 1.57, timestamp: Date.now() - 180000 },
    { id: '4', crashMultiplier: 1.96, timestamp: Date.now() - 240000 },
    { id: '5', crashMultiplier: 8.10, timestamp: Date.now() - 300000 },
    { id: '6', crashMultiplier: 1.15, timestamp: Date.now() - 360000 },
    { id: '7', crashMultiplier: 1.84, timestamp: Date.now() - 420000 },
    { id: '8', crashMultiplier: 4.52, timestamp: Date.now() - 480000 },
    { id: '9', crashMultiplier: 1.38, timestamp: Date.now() - 540000 },
    { id: '10', crashMultiplier: 14.80, timestamp: Date.now() - 600000 },
  ]);

  // My Personal Bets History
  const [myBetHistory, setMyBetHistory] = useState<
    Array<{ id: string; amount: number; multiplier: number | null; winAmount: number | null; timestamp: number }>
  >([
    { id: 'h-0', amount: 1000, multiplier: 1.53, winAmount: 1530, timestamp: Date.now() - 150000 },
  ]);

  // Simulated Live Multiplayer Bets
  const [livePlayers, setLivePlayers] = useState<LivePlayerBet[]>([]);

  // Refs for requestAnimationFrame loop
  const flightStartTimeRef = useRef<number>(0);
  const crashTargetRef = useRef<number>(1.84);
  const animFrameIdRef = useRef<number | null>(null);
  const currentMultiplierRef = useRef<number>(1.0);

  // Synchronization refs to prevent multiple trigger in animation frames
  const bet1StateRef = useRef(bet1);
  const bet2StateRef = useRef(bet2);
  const bet1CashedOutRef = useRef(false);
  const bet2CashedOutRef = useRef(false);

  useEffect(() => {
    bet1StateRef.current = bet1;
  }, [bet1]);

  useEffect(() => {
    bet2StateRef.current = bet2;
  }, [bet2]);

  // Keep track of active modal states for synchronous back-button popstate handling
  const openModalsRef = useRef({
    isSideDrawerOpen,
    isExitModalOpen,
    isAuthOpen,
    isDepositOpen,
    isRulesOpen,
    isAdminOpen,
    isInstallModalOpen,
    isAndroidStudioOpen,
    activeGameTab,
  });

  useEffect(() => {
    openModalsRef.current = {
      isSideDrawerOpen,
      isExitModalOpen,
      isAuthOpen,
      isDepositOpen,
      isRulesOpen,
      isAdminOpen,
      isInstallModalOpen,
      isAndroidStudioOpen,
      activeGameTab,
    };
  }, [
    isSideDrawerOpen,
    isExitModalOpen,
    isAuthOpen,
    isDepositOpen,
    isRulesOpen,
    isAdminOpen,
    isInstallModalOpen,
    isAndroidStudioOpen,
    activeGameTab,
  ]);

  // Phone Default Back Button & Double Back Exit Handling
  useEffect(() => {
    // Prime the browser history stack to trap back navigation
    window.history.replaceState({ page: 'root' }, '');
    window.history.pushState({ page: 'aviator-dashboard' }, '');

    const handlePopState = () => {
      const state = openModalsRef.current;
      const now = Date.now();

      // Case 1: If Exit modal is already open, 2nd back press exits the app!
      if (state.isExitModalOpen) {
        setIsExitModalOpen(false);
        setHasExitedApp(true);
        try {
          window.close();
        } catch {
          // browser might ignore window.close()
        }
        return;
      }

      // Case 2: Close 3-line side drawer menu
      if (state.isSideDrawerOpen) {
        setIsSideDrawerOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      // Case 3: Close any active modal
      if (state.isAuthOpen) {
        setIsAuthOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      if (state.isDepositOpen) {
        setIsDepositOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      if (state.isRulesOpen) {
        setIsRulesOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      if (state.isAdminOpen) {
        setIsAdminOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      if (state.isInstallModalOpen) {
        setIsInstallModalOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      if (state.isAndroidStudioOpen) {
        setIsAndroidStudioOpen(false);
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      // Case 4: If on sub-game (like Wingo), go back to Aviator dashboard
      if (state.activeGameTab !== 'AVIATOR') {
        setActiveGameTab('AVIATOR');
        window.history.pushState({ page: 'aviator-dashboard' }, '');
        return;
      }

      // Case 5: On the dashboard with no open modals -> Show Exit Confirmation Modal!
      soundManager.playClick();
      lastBackPressTimeRef.current = now;
      setIsExitModalOpen(true);
      window.history.pushState({ page: 'aviator-dashboard' }, '');
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Listen to Firebase Auth or restore saved Phone session
  useEffect(() => {
    // 1. Check if phone user session exists
    const phoneSession = getActivePhoneSession();
    if (phoneSession) {
      setCurrentUser(phoneSession.user);
      setUserProfile(phoneSession.profile);
      setBalance(phoneSession.profile.balance);
    }

    // 2. Listen to Firebase Google Auth state
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const profile = await getOrCreateUserProfile(user, 0);
          const appUser: AppUser = {
            uid: user.uid,
            displayName: user.displayName || 'Google Player',
            email: user.email,
            phoneNumber: profile.phoneNumber || user.phoneNumber || null,
            photoURL: user.photoURL,
            provider: 'google',
          };
          setCurrentUser(appUser);
          setUserProfile(profile);
          setBalance(profile.balance);
        } catch (err) {
          console.error('Error fetching Firestore user profile:', err);
        }
      } else {
        // If no firebase user, verify if there's a phone session
        const currentPhoneSession = getActivePhoneSession();
        if (!currentPhoneSession) {
          setCurrentUser(null);
          setUserProfile(null);
          setBalance(0);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Listen to manual deposit approval credit events and pending deposit badge count
  useEffect(() => {
    const handleBalanceCredited = (e: Event) => {
      const customEvent = e as CustomEvent<{ userId: string; amount: number; requestId: string }>;
      if (customEvent.detail && customEvent.detail.amount > 0) {
        const targetUid = customEvent.detail.userId;
        const targetPhone = targetUid.replace('phone_', '');
        if (
          !currentUser ||
          currentUser.uid === targetUid ||
          currentUser.phoneNumber === targetPhone ||
          currentUser.phoneNumber?.replace(/[^0-9]/g, '') === targetPhone
        ) {
          setBalance((prev) => prev + customEvent.detail.amount);
          setUserProfile((p) => (p ? { ...p, balance: p.balance + customEvent.detail.amount } : null));
          soundManager.playWin();
        }
      }
    };

    const updatePendingCount = () => {
      const depReqs = getStoredDepositRequests();
      const wthReqs = getStoredWithdrawalRequests();
      const pendingDep = depReqs.filter((r) => r.status === 'pending').length;
      const pendingWth = wthReqs.filter((r) => r.status === 'pending').length;
      setPendingDepositCount(pendingDep + pendingWth);
    };

    updatePendingCount();
    window.addEventListener('balance_credited', handleBalanceCredited);
    window.addEventListener('deposit_requests_updated', updatePendingCount);
    window.addEventListener('withdrawal_requests_updated', updatePendingCount);

    return () => {
      window.removeEventListener('balance_credited', handleBalanceCredited);
      window.removeEventListener('deposit_requests_updated', updatePendingCount);
      window.removeEventListener('withdrawal_requests_updated', updatePendingCount);
    };
  }, [currentUser]);

  // Sync balance updates with Firestore cloud wallet or Phone Account storage
  const updateBalanceAndSync = useCallback((updater: (prev: number) => number) => {
    setBalance((prev) => {
      const next = Math.max(0, Math.round(updater(prev) * 100) / 100);
      if (currentUser) {
        if (currentUser.provider === 'google') {
          syncUserBalanceToFirestore(currentUser.uid, next);
        } else {
          syncPhoneAccountBalance(currentUser.uid, next);
        }
        setUserProfile((p) => (p ? { ...p, balance: next } : null));
      }
      return next;
    });
  }, [currentUser]);

  // Generate Provably Fair Crash Multiplier (Strictly capped at max 50.00x)
  const generateNewCrashPoint = useCallback((): number => {
    const rand = Math.random();
    let point = 1.0;
    // 3.5% early crash (1.00x - 1.05x)
    if (rand < 0.035) point = +(1.0 + Math.random() * 0.05).toFixed(2);
    // 45% medium (1.10x - 2.10x)
    else if (rand < 0.485) point = +(1.1 + Math.random() * 1.0).toFixed(2);
    // 35% good (2.10x - 6.50x)
    else if (rand < 0.835) point = +(2.1 + Math.random() * 4.4).toFixed(2);
    // 13% high (6.50x - 22.00x)
    else if (rand < 0.965) point = +(6.5 + Math.random() * 15.5).toFixed(2);
    // 3.5% super high (capped strictly between 22.00x - 50.00x)
    else point = +(22.0 + Math.random() * 28.0).toFixed(2);

    return Math.min(50.00, Math.max(1.00, point));
  }, []);

  // Generate simulated players for each round
  const generateSimulatedPlayers = useCallback(() => {
    const names = [
      'Shanto_Vai',
      'Shakib_75',
      'Tamim_BD',
      'Rahim_VIP',
      'Priya_Queen',
      'Tanvir_Pro',
      'Rony_Dhaka',
      'Sumon_Trader',
      'Mehedi_Winner',
      'Anik_99',
      'Arif_Chittagong',
      'Nusrat_Win',
    ];
    const stakes = [50, 100, 200, 500, 1000, 2000, 5000];

    const players: LivePlayerBet[] = names.map((name, idx) => ({
      id: `p-${idx}-${Date.now()}`,
      playerName: name,
      avatarSeed: name,
      betAmount: stakes[Math.floor(Math.random() * stakes.length)],
      cashedOut: false,
    }));
    setLivePlayers(players);
  }, []);

  // Cash out handler for Panel 1 (strictly executed once)
  const handleCashOutPanel1 = useCallback((multiplierSnapshot?: unknown) => {
    if (bet1CashedOutRef.current) return;
    const currentBet = bet1StateRef.current;
    if (!currentBet.isPlaced || currentBet.cashedOut) return;

    bet1CashedOutRef.current = true;
    const mult =
      typeof multiplierSnapshot === 'number' && Number.isFinite(multiplierSnapshot)
        ? multiplierSnapshot
        : (currentMultiplierRef.current || 1.0);

    const win = Math.round(currentBet.amount * mult * 100) / 100;
    // Rule: New account starts with 100 bonus, can win up to 499 with free bonus.
    // If user has never deposited, max balance achievable is 499 unless they cash in (deposit).
    const hasDeposited = (userProfile?.totalDeposited || 0) > 0;
    let actualWin = win;
    if (!hasDeposited && balance + win > 499) {
      actualWin = Math.max(0, 499 - balance);
    }

    soundManager.playWin();

    setBet1((prev) => ({
      ...prev,
      cashedOut: true,
      cashedOutMultiplier: mult,
      winAmount: actualWin,
    }));

    updateBalanceAndSync((prev) => prev + actualWin);

    // Record user bet history
    recordUserBet({
      userId: currentUser?.uid || 'guest',
      userCode: userProfile?.userCode || currentUser?.userCode,
      gameType: 'aviator',
      stake: currentBet.amount,
      multiplier: mult,
      payout: actualWin,
      outcome: 'won',
    });

    if (currentUser && currentUser.provider === 'google') {
      recordBetHistory(currentUser.uid, 'aviator', currentBet.amount, mult, actualWin, 'won');
    }
    setWinNotification({ amount: actualWin, multiplier: mult });

    setMyBetHistory((prev) => [
      {
        id: `my-${Date.now()}-1`,
        amount: currentBet.amount,
        multiplier: mult,
        winAmount: actualWin,
        timestamp: Date.now(),
      },
      ...prev.slice(0, 19),
    ]);
  }, [updateBalanceAndSync, currentUser, userProfile, balance]);

  // Cash out handler for Panel 2 (strictly executed once)
  const handleCashOutPanel2 = useCallback((multiplierSnapshot?: unknown) => {
    if (bet2CashedOutRef.current) return;
    const currentBet = bet2StateRef.current;
    if (!currentBet.isPlaced || currentBet.cashedOut) return;

    bet2CashedOutRef.current = true;
    const mult =
      typeof multiplierSnapshot === 'number' && Number.isFinite(multiplierSnapshot)
        ? multiplierSnapshot
        : (currentMultiplierRef.current || 1.0);

    const win = Math.round(currentBet.amount * mult * 100) / 100;

    // Rule: New account starts with 100 bonus, can win up to 499 with free bonus.
    const hasDeposited = (userProfile?.totalDeposited || 0) > 0;
    let actualWin = win;
    if (!hasDeposited && balance + win > 499) {
      actualWin = Math.max(0, 499 - balance);
    }

    soundManager.playWin();

    setBet2((prev) => ({
      ...prev,
      cashedOut: true,
      cashedOutMultiplier: mult,
      winAmount: actualWin,
    }));

    updateBalanceAndSync((prev) => prev + actualWin);

    // Record user bet history
    recordUserBet({
      userId: currentUser?.uid || 'guest',
      userCode: userProfile?.userCode || currentUser?.userCode,
      gameType: 'aviator',
      stake: currentBet.amount,
      multiplier: mult,
      payout: actualWin,
      outcome: 'won',
    });

    if (currentUser && currentUser.provider === 'google') {
      recordBetHistory(currentUser.uid, 'aviator', currentBet.amount, mult, actualWin, 'won');
    }
    setWinNotification({ amount: actualWin, multiplier: mult });

    setMyBetHistory((prev) => [
      {
        id: `my-${Date.now()}-2`,
        amount: currentBet.amount,
        multiplier: mult,
        winAmount: actualWin,
        timestamp: Date.now(),
      },
      ...prev.slice(0, 19),
    ]);
  }, [updateBalanceAndSync, currentUser, userProfile, balance]);

  // Main Game Loop: WAITING -> FLYING -> CRASHED
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;

    if (roundStatus === 'WAITING') {
      soundManager.stopEngineSound();
      setCurrentMultiplier(1.0);
      currentMultiplierRef.current = 1.0;
      bet1CashedOutRef.current = false;
      bet2CashedOutRef.current = false;
      generateSimulatedPlayers();

      // Check auto bets
      if (bet1.isAutoBet && !bet1.isPlaced && balance >= bet1.amount) {
        setBalance((prev) => prev - bet1.amount);
        setBet1((prev) => ({ ...prev, isPlaced: true, cashedOut: false, winAmount: null }));
      }
      if (bet2.isAutoBet && !bet2.isPlaced && balance >= bet2.amount) {
        setBalance((prev) => prev - bet2.amount);
        setBet2((prev) => ({ ...prev, isPlaced: true, cashedOut: false, winAmount: null }));
      }

      // 5-second countdown
      const startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const remain = Math.max(0, 5.0 - elapsed);
        setWaitingCountdown(remain);

        if (remain <= 0) {
          clearInterval(interval);
          // Transition to FLYING
          const nextCrash = generateNewCrashPoint();
          crashTargetRef.current = nextCrash;
          setFinalCrashMultiplier(nextCrash);
          setRoundStatus('FLYING');
          soundManager.startEngineSound();
          flightStartTimeRef.current = Date.now();
        }
      }, 50);

      return () => clearInterval(interval);
    }

    if (roundStatus === 'FLYING') {
      let isFlying = true;

      const flyLoop = () => {
        if (!isFlying) return;

        const timeInSeconds = (Date.now() - flightStartTimeRef.current) / 1000;
        // Aviator exponential curve formula: multiplier grows smoothly
        const mult = 1.0 + 0.07 * timeInSeconds + 0.06 * Math.pow(timeInSeconds, 1.8);
        const roundedMult = Math.min(50.00, Math.round(mult * 100) / 100);
        currentMultiplierRef.current = roundedMult;

        soundManager.updateEnginePitch(roundedMult);

        // Check if other simulated players cash out
        setLivePlayers((prev) =>
          prev.map((p) => {
            if (!p.cashedOut && Math.random() < 0.02 && roundedMult < crashTargetRef.current) {
              return {
                ...p,
                cashedOut: true,
                cashedOutMultiplier: roundedMult,
                winAmount: Math.round(p.betAmount * roundedMult),
              };
            }
            return p;
          })
        );

        // Check Auto Cash Out Panel 1 (strictly once)
        if (
          !bet1CashedOutRef.current &&
          bet1StateRef.current.isPlaced &&
          !bet1StateRef.current.cashedOut &&
          bet1StateRef.current.isAutoCashOut &&
          roundedMult >= bet1StateRef.current.autoCashOutMultiplier
        ) {
          handleCashOutPanel1(roundedMult);
        }

        // Check Auto Cash Out Panel 2 (strictly once)
        if (
          !bet2CashedOutRef.current &&
          bet2StateRef.current.isPlaced &&
          !bet2StateRef.current.cashedOut &&
          bet2StateRef.current.isAutoCashOut &&
          roundedMult >= bet2StateRef.current.autoCashOutMultiplier
        ) {
          handleCashOutPanel2(roundedMult);
        }

        if (roundedMult >= crashTargetRef.current || roundedMult >= 50.00) {
          // CRASH EVENT! (Capped strictly at max 50x)
          isFlying = false;
          setCurrentMultiplier(Math.min(50.00, crashTargetRef.current));
          soundManager.playCrash();
          setRoundStatus('CRASHED');

          // Record lost bets
          if (bet1.isPlaced && !bet1.cashedOut) {
            recordUserBet({
              userId: currentUser?.uid || 'guest',
              userCode: userProfile?.userCode || currentUser?.userCode,
              gameType: 'aviator',
              stake: bet1.amount,
              multiplier: null,
              payout: 0,
              outcome: 'lost',
            });
            setMyBetHistory((h) => [
              { id: `lost-${Date.now()}-1`, amount: bet1.amount, multiplier: null, winAmount: null, timestamp: Date.now() },
              ...h.slice(0, 19),
            ]);
          }
          if (bet2.isPlaced && !bet2.cashedOut) {
            recordUserBet({
              userId: currentUser?.uid || 'guest',
              userCode: userProfile?.userCode || currentUser?.userCode,
              gameType: 'aviator',
              stake: bet2.amount,
              multiplier: null,
              payout: 0,
              outcome: 'lost',
            });
            setMyBetHistory((h) => [
              { id: `lost-${Date.now()}-2`, amount: bet2.amount, multiplier: null, winAmount: null, timestamp: Date.now() },
              ...h.slice(0, 19),
            ]);
          }

          // Add to multiplier history
          setHistory((prev) => [
            {
              id: String(Date.now()),
              crashMultiplier: crashTargetRef.current,
              timestamp: Date.now(),
              hash: 'sha256_' + Math.random().toString(36).substring(2, 15),
            },
            ...prev.slice(0, 19),
          ]);

          return;
        }

        setCurrentMultiplier(roundedMult);
        animFrameIdRef.current = requestAnimationFrame(flyLoop);
      };

      animFrameIdRef.current = requestAnimationFrame(flyLoop);

      return () => {
        isFlying = false;
        if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      };
    }

    if (roundStatus === 'CRASHED') {
      // Stay on crashed screen for 2.8 seconds, then reset for next round
      timer = setTimeout(() => {
        setBet1((prev) => ({
          ...prev,
          isPlaced: false,
          cashedOut: false,
          cashedOutMultiplier: null,
          winAmount: null,
        }));
        setBet2((prev) => ({
          ...prev,
          isPlaced: false,
          cashedOut: false,
          cashedOutMultiplier: null,
          winAmount: null,
        }));
        setRoundStatus('WAITING');
      }, 2800);

      return () => {
        if (timer) clearTimeout(timer);
      };
    }
  }, [
    roundStatus,
    bet1.isPlaced,
    bet1.cashedOut,
    bet1.isAutoCashOut,
    bet1.autoCashOutMultiplier,
    bet1.isAutoBet,
    bet2.isPlaced,
    bet2.cashedOut,
    bet2.isAutoCashOut,
    bet2.autoCashOutMultiplier,
    bet2.isAutoBet,
    balance,
    generateNewCrashPoint,
    generateSimulatedPlayers,
    handleCashOutPanel1,
    handleCashOutPanel2,
  ]);

  // Place Bet actions
  const handlePlaceBetPanel1 = (amount: number) => {
    if (roundStatus !== 'WAITING') return; // Strict: No bets allowed during flight or crash!
    if (balance < amount) return;
    soundManager.playClick();
    bet1CashedOutRef.current = false;
    updateBalanceAndSync((prev) => prev - amount);
    setBet1((prev) => ({ ...prev, amount, isPlaced: true, cashedOut: false, winAmount: null }));
  };

  const handleCancelBetPanel1 = () => {
    if (!bet1.isPlaced || roundStatus !== 'WAITING') return;
    soundManager.playClick();
    bet1CashedOutRef.current = false;
    updateBalanceAndSync((prev) => prev + bet1.amount);
    setBet1((prev) => ({ ...prev, isPlaced: false }));
  };

  const handlePlaceBetPanel2 = (amount: number) => {
    if (roundStatus !== 'WAITING') return; // Strict: No bets allowed during flight or crash!
    if (balance < amount) return;
    soundManager.playClick();
    bet2CashedOutRef.current = false;
    updateBalanceAndSync((prev) => prev - amount);
    setBet2((prev) => ({ ...prev, amount, isPlaced: true, cashedOut: false, winAmount: null }));
  };

  const handleCancelBetPanel2 = () => {
    if (!bet2.isPlaced || roundStatus !== 'WAITING') return;
    soundManager.playClick();
    bet2CashedOutRef.current = false;
    updateBalanceAndSync((prev) => prev + bet2.amount);
    setBet2((prev) => ({ ...prev, isPlaced: false }));
  };

  if (hasExitedApp) {
    return (
      <div className="fixed inset-0 bg-[#0b0e17] flex flex-col items-center justify-center p-6 text-center select-none text-white z-[9999]">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-600 to-rose-950 flex items-center justify-center mb-5 shadow-2xl shadow-red-900/60 border border-red-500/30 animate-scaleUp">
          <Plane className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-3xl font-black italic tracking-tighter text-[#E51D24] mb-2">
          Aviator BD
        </h2>
        <p className="text-lg font-bold text-slate-100 mb-1">
          অ্যাপ থেকে সফলভাবে বের হয়েছেন
        </p>
        <p className="text-xs text-slate-400 max-w-xs mb-8">
          আমাদের সাথে খেলার জন্য ধন্যবাদ! আপনি যেকোনো সময় পুনরায় গেমে ফিরতে পারেন।
        </p>
        <button
          onClick={() => {
            soundManager.playClick();
            setHasExitedApp(false);
            window.location.reload();
          }}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-lg shadow-red-700/40 active:scale-95 transition-all"
        >
          পুনরায় অ্যাপ চালু করুন
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-[#070a12] text-white flex justify-center font-sans select-none relative touch-manipulation p-[0.1rem] sm:p-2 box-border overflow-x-hidden">
      {/* 100% Mobile Phone Container (With 4-side .1 padding, rounded frame, zero overflow) */}
      <div className="w-full max-w-md min-h-[calc(100dvh-0.2rem)] bg-[#0c0f17] flex flex-col shadow-2xl relative rounded-xl border border-[#1e2a3f] overflow-x-hidden box-border">
        {/* Top Header with 3-Line Menu Button */}
        <Header
          balance={balance}
          currentUser={currentUser}
          userProfile={userProfile}
          onOpenMenu={() => setIsSideDrawerOpen(true)}
          onOpenAuth={() => setIsAuthOpen(true)}
          onOpenDeposit={() => {
            setWalletTab('deposit');
            setIsDepositOpen(true);
          }}
          onOpenWithdraw={() => {
            setWalletTab('withdraw');
            setIsDepositOpen(true);
          }}
          onOpenRules={() => setIsRulesOpen(true)}
          onOpenAdmin={() => setIsAdminOpen(true)}
          pendingDepositCount={pendingDepositCount}
          isMuted={isMuted}
          onToggleSound={() => {
            const next = !isMuted;
            setIsMuted(next);
            soundManager.setMuted(next);
          }}
          lang={lang}
          onToggleLang={() => setLang((prev) => (prev === 'bn' ? 'en' : 'bn'))}
          isPredictorOpen={isPredictorOpen}
          onTogglePredictor={() => setIsPredictorOpen((prev) => !prev)}
          onOpenInstallModal={() => setIsInstallModalOpen(true)}
          isAppInstalled={isAppInstalled}
        />

        {/* Right-to-Left Scrolling Announcement Banner ("শিরোনাম") */}
        <MarqueeTicker />

        {/* Main Container */}
        <main className="flex-1 w-full max-w-full p-1.5 sm:p-2 flex flex-col gap-2 relative pb-24 overflow-x-hidden box-border">
        {/* Aviator Mode */}
        {activeGameTab === 'AVIATOR' && (
          <>
            {/* Multiplier History Ribbon */}
            <HistoryRibbon history={history} />

            {/* Canvas Stage */}
            <div className="relative">
              <FlightCanvas
                status={roundStatus}
                currentMultiplier={currentMultiplier}
                finalCrashMultiplier={finalCrashMultiplier}
                waitingCountdown={waitingCountdown}
                lang={lang}
              />

              {/* Floating Win Banner */}
              {winNotification && (
                <WinNotification
                  amount={winNotification.amount}
                  multiplier={winNotification.multiplier}
                  onClose={() => setWinNotification(null)}
                />
              )}

              {/* AI Signal Predictor widget */}
              <AIPredictorModal
                isOpen={isPredictorOpen}
                onClose={() => setIsPredictorOpen(false)}
                recentMultipliers={history.map((h) => h.crashMultiplier)}
                roundStatus={roundStatus}
              />
            </div>

            {/* Dual Betting Controls: Panel 1 & Panel 2 (Both visible simultaneously in same view - no tab switching) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div>
                <BetPanel
                  panelIndex={1}
                  bet={bet1}
                  roundStatus={roundStatus}
                  currentMultiplier={currentMultiplier}
                  balance={balance}
                  onPlaceBet={handlePlaceBetPanel1}
                  onCancelBet={handleCancelBetPanel1}
                  onCashOut={() => handleCashOutPanel1()}
                  onUpdateAutoSettings={(autoBet, autoCash, autoMult) =>
                    setBet1((prev) => ({
                      ...prev,
                      isAutoBet: autoBet,
                      isAutoCashOut: autoCash,
                      autoCashOutMultiplier: autoMult,
                    }))
                  }
                  lang={lang}
                />
              </div>

              <div>
                <BetPanel
                  panelIndex={2}
                  bet={bet2}
                  roundStatus={roundStatus}
                  currentMultiplier={currentMultiplier}
                  balance={balance}
                  onPlaceBet={handlePlaceBetPanel2}
                  onCancelBet={handleCancelBetPanel2}
                  onCashOut={() => handleCashOutPanel2()}
                  onUpdateAutoSettings={(autoBet, autoCash, autoMult) =>
                    setBet2((prev) => ({
                      ...prev,
                      isAutoBet: autoBet,
                      isAutoCashOut: autoCash,
                      autoCashOutMultiplier: autoMult,
                    }))
                  }
                  lang={lang}
                />
              </div>
            </div>

            {/* Multiplayer Live Bets & History */}
            <LiveBetsTable
              livePlayers={livePlayers}
              myBetHistory={myBetHistory}
              lang={lang}
            />
          </>
        )}

        {/* Wingo Mode */}
        {activeGameTab === 'WINGO' && (
          <WingoGame
            balance={balance}
            onUpdateBalance={(delta) => updateBalanceAndSync((prev) => prev + delta)}
            lang={lang}
          />
        )}
      </main>

      {/* Mobile Native App Bottom Navigation Bar (Uniform on all viewports) */}
      <MobileBottomNav
        activeTab={activeGameTab}
        onSelectTab={(tab) => setActiveGameTab(tab)}
        onOpenDeposit={() => {
          setWalletTab('deposit');
          setIsDepositOpen(true);
        }}
        onOpenWithdraw={() => {
          setWalletTab('withdraw');
          setIsDepositOpen(true);
        }}
        onOpenAuth={() => setIsAuthOpen(true)}
        onTogglePredictor={() => setIsPredictorOpen((prev) => !prev)}
        isPredictorOpen={isPredictorOpen}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isAppInstalled={isAppInstalled}
        currentUser={currentUser}
      />

      {/* Modals */}
      <DepositModal
        isOpen={isDepositOpen}
        onClose={() => setIsDepositOpen(false)}
        currentBalance={balance}
        initialTab={walletTab}
        onAddFunds={(amt) => {
          updateBalanceAndSync((prev) => prev + amt);
          if (currentUser && currentUser.provider === 'google') {
            recordWalletTransaction(currentUser.uid, {
              type: 'deposit',
              amount: amt,
              method: 'bkash',
              accountNumber: userProfile?.phoneNumber || '01712-345678',
              status: 'completed',
              trxId: 'DEP' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            });
          }
        }}
        onWithdrawFunds={(amt) => {
          updateBalanceAndSync((prev) => Math.max(0, Math.round((prev - amt) * 100) / 100));
          if (currentUser && currentUser.provider === 'google') {
            recordWalletTransaction(currentUser.uid, {
              type: 'withdraw',
              amount: amt,
              method: 'bkash',
              accountNumber: userProfile?.phoneNumber || '01712-345678',
              status: 'completed',
              trxId: 'WTH' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            });
          }
        }}
        onResetBalance={() => {
          updateBalanceAndSync(() => INITIAL_BALANCE);
        }}
        lang={lang}
        userPhone={userProfile?.phoneNumber}
        currentUser={currentUser}
        userProfile={userProfile}
        onOpenAdminPanel={() => setIsAdminOpen(true)}
      />

      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
        lang={lang}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        userProfile={userProfile}
        onLoginSuccess={(user, profile) => {
          setCurrentUser(user);
          setUserProfile(profile);
          setBalance(profile.balance);
        }}
        onLogoutSuccess={() => {
          setCurrentUser(null);
          setUserProfile(null);
          setBalance(INITIAL_BALANCE);
        }}
        onResetBalance={() => {
          updateBalanceAndSync(() => 0);
        }}
        onUpdatePhone={(phone) => {
          setUserProfile((p) => (p ? { ...p, phoneNumber: phone } : null));
        }}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onBalanceAdjusted={() => {
          // If phone session exists, refresh state
          const currentPhoneSession = getActivePhoneSession();
          if (currentPhoneSession && currentUser?.uid === currentPhoneSession.user.uid) {
            setBalance(currentPhoneSession.profile.balance);
            setUserProfile(currentPhoneSession.profile);
          }
        }}
      />

      {/* PWA Mobile App Install Modal */}
      <PWAInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        onOpenAndroidStudio={() => setIsAndroidStudioOpen(true)}
      />

      {/* Android Studio Export & APK Generation Guide Modal */}
      <AndroidStudioExportModal
        isOpen={isAndroidStudioOpen}
        onClose={() => setIsAndroidStudioOpen(false)}
      />

      {/* 3-Line Top Left Mobile Side Drawer Menu */}
      <MobileSideDrawer
        isOpen={isSideDrawerOpen}
        onClose={() => setIsSideDrawerOpen(false)}
        currentUser={currentUser}
        userProfile={userProfile}
        balance={balance}
        activeGameTab={activeGameTab}
        onChangeGameTab={(tab) => setActiveGameTab(tab)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenDeposit={() => {
          setWalletTab('deposit');
          setIsDepositOpen(true);
        }}
        onOpenWithdraw={() => {
          setWalletTab('withdraw');
          setIsDepositOpen(true);
        }}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        isPredictorOpen={isPredictorOpen}
        onTogglePredictor={() => setIsPredictorOpen((prev) => !prev)}
        isMuted={isMuted}
        onToggleSound={() => {
          const next = !isMuted;
          setIsMuted(next);
          soundManager.setMuted(next);
        }}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'bn' ? 'en' : 'bn'))}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onOpenAndroidStudio={() => setIsAndroidStudioOpen(true)}
        onExitApp={() => setIsExitModalOpen(true)}
      />

      {/* Phone Default Back Button & Double Back Exit Confirmation Modal */}
      <ExitModal
        isOpen={isExitModalOpen}
        onClose={() => setIsExitModalOpen(false)}
        onConfirmExit={() => {
          setIsExitModalOpen(false);
          setHasExitedApp(true);
          try {
            window.close();
          } catch {
            // ignore
          }
        }}
      />

      {/* 1-Second Initial Mobile Splash Screen */}
      {showSplash && (
        <SplashScreen onFinish={handleFinishSplash} />
      )}
      </div>
    </div>
  );
}
