import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker immediately for offline capability and mobile app performance
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('Aviator Mobile App: Update available');
  },
  onOfflineReady() {
    console.log('Aviator Mobile App: Ready for offline operation');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
