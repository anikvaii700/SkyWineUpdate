import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Download,
  AlertTriangle,
  CheckCircle2,
  Copy,
  FileCode,
  Layers,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ExternalLink,
  HelpCircle,
} from 'lucide-react';
import { soundManager } from '../services/audio';

interface AndroidStudioExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidStudioExportModal: React.FC<AndroidStudioExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'why-failed' | 'ready-project' | 'manual-code'>('ready-project');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleCopy = (key: string, text: string) => {
    soundManager.playClick();
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const codeManifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:label="Aviator BD"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const codeMainActivity = `package com.aviator.crash;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private long backPressedTime;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Dark status bar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#070a12"));
            window.setNavigationBarColor(Color.parseColor("#0a0e18"));
        }

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        // Hardware acceleration for smooth 60fps plane animations
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setBackgroundColor(Color.parseColor("#070a12"));

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        // Load bundled web app assets or live URL
        webView.loadUrl("file:///android_asset/www/index.html");

        // Native back button handling
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    if (backPressedTime + 2000 > System.currentTimeMillis()) {
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, "অ্যাপ থেকে বের হতে আবার ব্যাক চাপুন", Toast.LENGTH_SHORT).show();
                    }
                    backPressedTime = System.currentTimeMillis();
                }
            }
        });
    }
}`;

  const codeLayout = `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#070a12">

    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-lg bg-[#0e1422] border border-[#22314a] rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-200">
        
        {/* Modal Header */}
        <div className="p-4 bg-gradient-to-r from-[#172033] via-[#131b2e] to-[#0e1422] border-b border-[#212f45] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                Android Studio APK গাইড ও এক্সপোর্ট
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  ১০০% ফিক্স
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                ফেইল আসার কারণ, তৈরি অ্যান্ড্রয়েড প্রজেক্ট ও APK তৈরির নিয়ম
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-[#1b2538] hover:bg-[#25334d] text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 bg-[#0a0f18] p-1.5 border-b border-[#1b2639] gap-1 text-xs font-bold">
          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('ready-project');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'ready-project'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>তৈরি প্রজেক্ট (.zip)</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('why-failed');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'why-failed'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>ফেইল কেন আসে?</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('manual-code');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'manual-code'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2d]'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>জাভা ও ম্যানিফেস্ট কোড</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          
          {/* TAB 1: READY PROJECT DOWNLOAD */}
          {activeTab === 'ready-project' && (
            <div className="space-y-4">
              <div className="bg-emerald-950/40 border border-emerald-600/40 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>আপনার জন্য রেডিমেড Android Studio প্রজেক্ট তৈরি করে রাখা হয়েছে!</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আপনাকে কোনো কোডিং করতে হবে না। নিচের বাটনে চাপ দিয়ে রেডিমেড জিপ ডাউনলোড করুন এবং সরাসরি Android Studio তে ওপেন করে ১ ক্লিকে APK বিল্ড করুন।
                </p>
              </div>

              {/* Download Buttons */}
              <div className="space-y-2.5">
                <a
                  href="/aviator-android-studio-project.zip"
                  download="Aviator-Android-Studio-Project.zip"
                  onClick={() => soundManager.playClick()}
                  className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>📥 Android Studio প্রজেক্ট ডাউনলোড (.zip)</span>
                </a>

                <a
                  href="/aviator-full-source-code.zip"
                  download="Aviator-Full-Source-Code.zip"
                  onClick={() => soundManager.playClick()}
                  className="w-full py-3 px-4 bg-[#162032] hover:bg-[#1e2c45] border border-[#273854] text-slate-200 font-bold text-xs rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
                >
                  <Layers className="w-4 h-4 text-sky-400" />
                  <span>📦 সম্পূর্ণ ওয়েব সোর্স কোড ডাউনলোড (.zip)</span>
                </a>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="bg-[#121929] border border-[#1e2a3f] rounded-2xl p-3.5 space-y-2.5">
                <h4 className="font-bold text-amber-400 text-xs flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Android Studio তে APK বানানোর ৩টি সহজ ধাপ:</span>
                </h4>
                
                <ol className="space-y-2 text-[11px] text-slate-300">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ১
                    </span>
                    <span>
                      ডাউনলোড করা <strong>Aviator-Android-Studio-Project.zip</strong> ফাইলটি কম্পিউটারে Extract (আনজিপ) করুন।
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ২
                    </span>
                    <span>
                      Android Studio ওপেন করে <strong>File → Open</strong> চাপুন এবং আনজিপ করা ফোল্ডারটি সিলেক্ট করুন। (Gradle Sync নিজে থেকেই সফলভাবে শেষ হবে)।
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      ৩
                    </span>
                    <span>
                      উপরের মেনু থেকে <strong>Build → Build Bundle(s) / APK(s) → Build APK(s)</strong> চাপুন। ৩০ সেকেন্ডের মধ্যে আপনার ফোনে ইনস্টল করার মতো <strong>.apk</strong> ফাইল তৈরি হয়ে যাবে!
                    </span>
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 2: WHY FAILED EXPLANATION */}
          {activeTab === 'why-failed' && (
            <div className="space-y-3.5">
              <div className="bg-amber-950/30 border border-amber-600/40 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>অ্যান্ড্রয়েড স্টুডিওতে সরাসরি কোড নিলে "ফেইল" আসার কারণ:</span>
                </div>
                <div className="space-y-2 text-[11px] text-slate-300 leading-relaxed">
                  <p>
                    🔴 <strong>কারণ ১ (প্রজেক্ট ফরম্যাট অমিল):</strong> এই প্রজেক্টটি তৈরি <strong>React + Vite + TypeScript</strong> দিয়ে। কিন্তু Android Studio হলো <strong>Java / Kotlin / Gradle</strong> প্ল্যাটফর্ম। ওয়েব প্রজেক্টে <code className="bg-black/50 px-1 py-0.5 rounded text-amber-300">package.json</code> থাকে, কিন্তু অ্যান্ড্রয়েড স্টুডিও খোঁজে <code className="bg-black/50 px-1 py-0.5 rounded text-emerald-300">build.gradle</code> ও <code className="bg-black/50 px-1 py-0.5 rounded text-emerald-300">AndroidManifest.xml</code>।
                  </p>
                  <p>
                    🔴 <strong>কারণ ২ (সরাসরি ওপেন করা):</strong> ওয়েব কোডের ফোল্ডার সরাসরি Android Studio তে ওপেন করলে অ্যান্ড্রয়েড স্টুডিও বলে: <em>"Gradle project sync failed"</em> অথবা <em>"No Android facet found"</em>।
                  </p>
                  <p>
                    🔴 <strong>কারণ ৩ (বিল্ড না করা):</strong> ব্রাউজারের TSX কোডকে আগে <code className="bg-black/50 px-1 py-0.5 rounded text-cyan-300">dist</code> ফোল্ডারে বিল্ড করে Android এর <code className="bg-black/50 px-1 py-0.5 rounded text-cyan-300">assets/www</code> এ রাখতে হয়।
                  </p>
                </div>
              </div>

              <div className="bg-[#121929] border border-[#1e2a3f] rounded-2xl p-3.5 space-y-2">
                <h4 className="font-bold text-emerald-400 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>আমরা আপনার জন্য কী সমাধান করেছি?</span>
                </h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আমরা সম্পূর্ণ <strong>Android Studio Project (settings.gradle, build.gradle, MainActivity.java, AndroidManifest.xml ও assets)</strong> স্বয়ংক্রিয়ভাবে তৈরি করে প্যাকেজ করে দিয়েছি।
                  <br />
                  আপনি শুধু <strong>"তৈরি প্রজেক্ট (.zip)"</strong> ট্যাব থেকে জিপ ফাইলটি ডাউনলোড করে Android Studio তে ওপেন করলেই ১০০% ফেইল ছাড়াই কাজ করবে!
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: MANUAL JAVA & MANIFEST CODE */}
          {activeTab === 'manual-code' && (
            <div className="space-y-3.5">
              <p className="text-[11px] text-slate-300">
                আপনি যদি নিজের মতো করে Android Studio তে <strong>New Project → Empty Views Activity</strong> খুলে কোড পেস্ট করতে চান, নিচের কোডগুলো ব্যবহার করুন:
              </p>

              {/* MainActivity.java */}
              <div className="bg-[#0b101a] border border-[#1e293c] rounded-2xl overflow-hidden">
                <div className="bg-[#141b2a] px-3 py-2 flex items-center justify-between border-b border-[#1e293c]">
                  <span className="font-mono text-[11px] text-sky-400 font-bold">MainActivity.java</span>
                  <button
                    onClick={() => handleCopy('main_activity', codeMainActivity)}
                    className="flex items-center gap-1 text-[10px] font-bold bg-[#1e293c] hover:bg-[#283850] text-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    {copiedKey === 'main_activity' ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">কপি হয়েছে!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>কপি করুন</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 text-[10px] font-mono text-slate-300 overflow-x-auto max-h-40 leading-relaxed">
                  {codeMainActivity}
                </pre>
              </div>

              {/* AndroidManifest.xml */}
              <div className="bg-[#0b101a] border border-[#1e293c] rounded-2xl overflow-hidden">
                <div className="bg-[#141b2a] px-3 py-2 flex items-center justify-between border-b border-[#1e293c]">
                  <span className="font-mono text-[11px] text-amber-400 font-bold">AndroidManifest.xml</span>
                  <button
                    onClick={() => handleCopy('manifest', codeManifest)}
                    className="flex items-center gap-1 text-[10px] font-bold bg-[#1e293c] hover:bg-[#283850] text-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    {copiedKey === 'manifest' ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">কপি হয়েছে!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>কপি করুন</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 text-[10px] font-mono text-slate-300 overflow-x-auto max-h-36 leading-relaxed">
                  {codeManifest}
                </pre>
              </div>

              {/* activity_main.xml */}
              <div className="bg-[#0b101a] border border-[#1e293c] rounded-2xl overflow-hidden">
                <div className="bg-[#141b2a] px-3 py-2 flex items-center justify-between border-b border-[#1e293c]">
                  <span className="font-mono text-[11px] text-emerald-400 font-bold">res/layout/activity_main.xml</span>
                  <button
                    onClick={() => handleCopy('layout', codeLayout)}
                    className="flex items-center gap-1 text-[10px] font-bold bg-[#1e293c] hover:bg-[#283850] text-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    {copiedKey === 'layout' ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">কপি হয়েছে!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>কপি করুন</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 text-[10px] font-mono text-slate-300 overflow-x-auto max-h-32 leading-relaxed">
                  {codeLayout}
                </pre>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-[#0a0e17] border-t border-[#1e273b] flex items-center justify-between">
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Android SDK 34 • Gradle 8.2 • 60 FPS</span>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="px-4 py-2 bg-[#1b2538] hover:bg-[#25334d] text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>

      </div>
    </div>
  );
};
